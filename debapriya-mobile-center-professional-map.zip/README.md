# Debapriya Mobile Center & Xerox — Professional Website

A responsive static business website created from the supplied Debapriya Mobile Center & Xerox poster.

## Included
- Professional responsive homepage
- Sticky navigation
- Services section
- About / why visit section
- Call and WhatsApp buttons
- Google Maps direction button
- Original supplied poster used as the shop visual
- Mobile-friendly floating contact buttons
- GitHub Pages ready

## Publish on GitHub Pages
1. Create a **Public** repository.
2. Upload all files and folders from this project.
3. Keep `index.html` in the repository root.
4. Open **Settings → Pages**.
5. Under Build and deployment select **Deploy from a branch**.
6. Select **main** and **/(root)**, then Save.

The Contact section uses the supplied Google Maps listing for Debapriya Mobile.
