# Debapriya Mobile Center & Xerox

One-page professional website for GitHub Pages.

## Upload to GitHub
Upload these two files to the root of your repository:
- `index.html`
- `shop-poster.png`

Then enable GitHub Pages from **Settings → Pages → Deploy from a branch → main → /(root)**.

The page includes:
- Shop poster image
- Call button
- WhatsApp button
- Exact Google Maps listing
- Services section
- Responsive mobile/desktop design
